﻿namespace WebApplication1_Prosjekt1.Model
{
    public class Pasient
    {
        public int id { get; set; }
        public string navn { get; set; }
        public string adresse { get; set; }

        public string diagnose { get; set; }
    }
}
